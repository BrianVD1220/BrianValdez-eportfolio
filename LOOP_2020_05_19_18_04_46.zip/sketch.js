var textx=0;

function setup() {   
   createCanvas(600,400);
}

function draw() { 
   background(64,224,208);   
   fill(230,230,250);   
   noStroke();   
   textSize(50);   
   textFont("AMERICAN TYPEWRITER");   
   textStyle(BOLD);   
   textAlign(LEFT);   
   text("GOOD MORNING!",textx,350);     
          //add a conditional
  if(textx>600){     
     textx = 0;   
  }else{     
     textx=textx + 5;   
  }
}